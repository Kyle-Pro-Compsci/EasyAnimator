package cs3500.animator.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import javax.swing.BorderFactory;
import javax.swing.JScrollPane;
import javax.swing.BoxLayout;


import cs3500.shapes.IShape;
import cs3500.shapes.ShapeType;

/**
 * Provides a view for a model's animation by providing a visual representation of
 * the model's shapes in each frame of the animation, as well as the front-end visual interface
 * that allows for media-player interaction with the animation.
 */
public class AnimatorHybridView extends JFrame implements IAnimatorHybridView {


  private AnimatorPanel animationPanel;
  private ArrayList<JCheckBox> checkboxList;

  private JButton playButton;
  private JButton restartButton;
  private JButton increaseButton;
  private JButton decreaseButton;
  private JButton loopButton;

  /**
   * The constructor for AnimatorHybridView. It initializes and sets the attributes of all the
   * Java Swing components that make up the interface. Sets the shapes and the time of this
   * View to the given shapes and time.
   * @param shapes The shapes to render.
   * @param time The current timeframe for the animation.
   */
  public AnimatorHybridView(ArrayList<IShape> shapes, int time) {
    super();

    JPanel containerPanel;
    JPanel buttonPanel;
    JPanel shapePanel;


    this.setTitle("EasyAnimator");
    this.setSize(1200, 1000);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setLayout(new BorderLayout());

    //initialize buttons
    this.playButton = new JButton("Play/Pause");
    this.restartButton = new JButton("Restart");
    this.increaseButton = new JButton("Increase tickrate");
    this.decreaseButton = new JButton("Decrease tickrate");
    this.loopButton = new JButton("Toggle loop");

    //set action commands for buttons
    this.playButton.setActionCommand("Play/Pause");
    this.restartButton.setActionCommand("Restart");
    this.increaseButton.setActionCommand("Increase tickrate");
    this.decreaseButton.setActionCommand("Decrease tickrate");
    this.loopButton.setActionCommand("Toggle loop");

    //customize panels
    this.animationPanel = new AnimatorPanel(shapes, time);
    this.repaint();

    buttonPanel = new JPanel();
    shapePanel = new JPanel();
    containerPanel = new JPanel();
    shapePanel.setLayout(new BoxLayout(shapePanel, BoxLayout.PAGE_AXIS));
    buttonPanel.setLayout(new FlowLayout());
    buttonPanel.setBorder(BorderFactory.createBevelBorder(1));
    shapePanel.setBorder(BorderFactory.createBevelBorder(1));

    // add buttons to buttonPanel
    buttonPanel.add(playButton);
    buttonPanel.add(restartButton);
    buttonPanel.add(increaseButton);
    buttonPanel.add(decreaseButton);
    buttonPanel.add(loopButton);

    //fill out the shapePanel with checkboxes
    this.checkboxList = new ArrayList<JCheckBox>();

    for (IShape shape : shapes) {
      String shapeType;
      if (shape.getType() == ShapeType.RECTANGLE) {
        shapeType = "Rectangle";
      }
      else {
        shapeType = "Oval";
      }
      String shapeText = shape.getName() + ", " + shapeType;
      JCheckBox cb = new JCheckBox(shapeText);
      cb.setActionCommand("check box");
      shapePanel.add(cb);
      checkboxList.add(cb);
    }

    for (JCheckBox checkBox : checkboxList) {
      checkBox.setSelected(true);
    }

    // Add 2 panels to scrollpanes, and add all to the overall containerPanel
    JScrollPane animationScrollPane = new JScrollPane(animationPanel);
    JScrollPane shapeScrollPane = new JScrollPane(shapePanel);
    containerPanel.setLayout(new BorderLayout());
    containerPanel.add(animationScrollPane, BorderLayout.CENTER);
    containerPanel.add(shapeScrollPane, BorderLayout.EAST);
    containerPanel.add(buttonPanel, BorderLayout.SOUTH);

    this.add(containerPanel, BorderLayout.CENTER);
  }


  @Override
  public void view() {
    this.setVisible(true);
  }

  @Override
  public void refresh(ArrayList<IShape> shapes, int time) {

    ArrayList<IShape> shapesToDraw = new ArrayList<IShape>();

    for (int i = 0; i < this.checkboxList.size(); i++) {
      if (checkboxList.get(i).isSelected()) {
        shapesToDraw.add(shapes.get(i));
      }
    }

    this.animationPanel.setShapes(shapesToDraw, time);
    this.repaint();
  }

  @Override
  public void setListener(ActionListener buttons) {
    this.playButton.addActionListener(buttons);
    this.restartButton.addActionListener(buttons);
    this.increaseButton.addActionListener(buttons);
    this.decreaseButton.addActionListener(buttons);
    this.loopButton.addActionListener(buttons);
    for (JCheckBox cb : this.checkboxList) {
      cb.addActionListener(buttons);
    }
  }
}
