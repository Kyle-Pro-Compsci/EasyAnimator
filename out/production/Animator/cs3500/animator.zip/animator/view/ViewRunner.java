package cs3500.animator.view;

import java.awt.Color;
import java.io.FileNotFoundException;

import cs3500.animator.animations.ChangeColor;
import cs3500.animator.animations.IAnimation;
import cs3500.animator.animations.Move;
import cs3500.animator.animations.Scale;
import cs3500.animator.controller.AnimatorController;
import cs3500.animator.controller.IAnimatorController;
import cs3500.animator.model.IAnimationModel;
import cs3500.animator.model.SimpleAnimationModel;
import cs3500.animator.util.AnimationFileReader;
import cs3500.shapes.Coordinate;
import cs3500.shapes.IShape;
import cs3500.shapes.Oval;
import cs3500.shapes.Rectangle;

import cs3500.animator.model.SimpleAnimationModel.Builder;

public class ViewRunner {

  public static void main (String[] args) {
    IAnimationModel model = new SimpleAnimationModel();


    IShape circle = new Oval(new Coordinate(25, 25), new Color(213, 156, 156), "circle", 0, 500, 10, 10);
    IShape rectangle = new Rectangle(new Coordinate(150, 150), Color.BLUE, "rectangle", 50, 600, 40, 20);
    model.addShape(circle);
    model.addShape(rectangle);

    IAnimation moveCircle = new Move("circle", 50, 250, new Coordinate(25, 25), new Coordinate(1300, 25));
    IAnimation colorChangeRectangle = new ChangeColor("rectangle", 80, 150, Color.BLUE, Color.GREEN);
    IAnimation scaleCircle = new Scale("circle", 110, 200, 10, 10, 1000, 1000);

    model.addAnimation(moveCircle);
    model.addAnimation(colorChangeRectangle);
    model.addAnimation(scaleCircle);
//
//    IAnimatorView textView = new AnimatorTextView(model, 2);
//    textView.view();
//
//    IAnimatorView svgView = new AnimatorSVGView(model, 10);
//    svgView.view();
//
//    IAnimatorHybridView visualView = new AnimatorHybridView(model, 24);
//    visualView.view();

    AnimationFileReader reader = new AnimationFileReader();
    IAnimationModel m1 = new SimpleAnimationModel();
    try {
      m1 = reader.readFile("buildings.txt", new Builder());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }

//    IAnimatorView svgView = new AnimatorSVGView(m1, 20);
//    svgView.view();
//
//    IAnimatorView textView = new AnimatorTextView(m1, 20);
//    textView.view();
//
//    IAnimatorView visualView = new AnimatorVisualView(m1, 20);
//    visualView.view();

    IAnimatorHybridView hybridView = new AnimatorHybridView(m1.getShapes(), m1.getTime());
    IAnimatorController controller = new AnimatorController(hybridView, m1, 24);
  }

}
