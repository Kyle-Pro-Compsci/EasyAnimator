package cs3500.animator.view;

import java.awt.event.ActionListener;
import java.util.ArrayList;

import cs3500.shapes.IShape;

/**
 * The interface for a visual animator view.
 */
public interface IAnimatorHybridView extends IAnimatorView {

  /**
   * Refreshes the visual view to draw a new set of given shapes based on a given time frame.
   * @param shapes The new set of shapes to draw.
   * @param time The current time frame to draw at.
   */
  void refresh(ArrayList<IShape> shapes, int time);

  void setListener(ActionListener buttons);
}
