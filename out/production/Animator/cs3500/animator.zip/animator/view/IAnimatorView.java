package cs3500.animator.view;

/**
 * The interface for a general animator view.
 */
public interface IAnimatorView {

  /**
   * Enscribes the text of an animation model to the console.
   */
  void view();
}
