package cs3500.animator.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.Timer;
import javax.swing.BorderFactory;

import cs3500.animator.model.IAnimationModel;

/**
 * Provides a view for a model's animation by providing a visual representation of the model's
 * shapes in each frame of the animation.
 */
public class AnimatorVisualView extends JFrame implements IAnimatorVisualView {

  private JPanel containerPanel;
  private AnimatorPanel animationPanel;
  private JPanel buttonPanel;
  private JPanel shapePanel;
  private IAnimationModel model;
  private int tickrate;

  /**
   * Constructor an AnimatorVisualView that animates the given model at the given tickrate.
   *
   * @param model    The IAnimationModel to animate, using its shapes and animations.
   * @param tickrate The speed at which to play the animation.
   */
  public AnimatorVisualView(IAnimationModel model, int tickrate) {
    super();
    this.setTitle("EasyAnimator");
    this.setSize(1200, 1000);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setLayout(new BorderLayout());

    this.model = model;
    this.tickrate = tickrate;

    JButton playButton = new JButton("Play/Pause");
    JButton restartButton = new JButton("Restart");

    playButton.setActionCommand("Play/Pause");
    playButton.setActionCommand("Restart");

    this.animationPanel = new AnimatorPanel(model.getShapes(), model.getTime());
    this.buttonPanel = new JPanel();
    this.buttonPanel.setLayout(new FlowLayout());
    this.buttonPanel.setBorder(BorderFactory.createBevelBorder(1));

    this.buttonPanel.add(playButton);
    this.buttonPanel.add(restartButton);

    this.shapePanel = new JPanel();
    this.shapePanel.setBorder(BorderFactory.createBevelBorder(1));
    this.containerPanel = new JPanel();

    this.containerPanel.setLayout(new BorderLayout());
    this.containerPanel.add(animationPanel, BorderLayout.CENTER);
    this.containerPanel.add(shapePanel, BorderLayout.EAST);
    this.containerPanel.add(buttonPanel, BorderLayout.SOUTH);

    JScrollPane scrollPane = new JScrollPane(this.containerPanel);
    this.add(scrollPane, BorderLayout.CENTER);
  }


  @Override
  public void view() {
    this.setVisible(true);
    this.startAnimation();
  }

  @Override
  public void refresh() {
    this.model.tickTime();
    this.model.performAnimations();
    this.animationPanel.setShapes(this.model.getShapes(), this.model.getTime());
    //this.revalidate();
    this.repaint();
  }

  /**
   * Runs the animation by calling refresh() on each tick of the timer, the speed of which is based
   * on the tickrate.
   */
  private void startAnimation() {

    ActionListener taskPerformer = evt -> refresh();

    Timer timer = new Timer(1000 / tickrate, taskPerformer);
    timer.start();
  }
}