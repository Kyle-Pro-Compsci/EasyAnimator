package cs3500.animator.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.Timer;

import cs3500.animator.model.IAnimationModel;
import cs3500.animator.view.IAnimatorHybridView;
import cs3500.shapes.IShape;

/**
 * The controller that interacts with an IAnimatorHybridView using data from an IAnimationModel.
 * Allows for media-player-esque control over the visual view for an animation.
 */
public class AnimatorController implements IAnimatorController, ActionListener {

  private IAnimatorHybridView view;
  private IAnimationModel model;
  private ArrayList<IShape> startingShapes;
  private int tickrate;
  private boolean running;
  private boolean looping;
  private Timer timer;

  /**
   * Constructs an Animator Controller, which should have control over a hybrid view.
   * @param view The IAnimatorHybridView to control.
   * @param model The model to be used to view.
   * @param tickrate The starting tick rate of the view.
   */
  public AnimatorController(IAnimatorHybridView view, IAnimationModel model, int tickrate) {
    this.view = view;
    this.model = model;
    this.tickrate = tickrate;
    this.running = false;
    this.startingShapes = model.getShapes();

    this.view.setListener(this);
    ActionListener taskPerformer = evt -> refresh();

    this.timer = new Timer(1000 / tickrate, taskPerformer);

    this.view.view();
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    switch (e.getActionCommand()) {
      case "Play/Pause":
        if (running) {
          this.pause();
          running = false;
        }
        else {
          this.start();
          running = true;
        }
        break;
      case "Restart":
        this.restart();
        break;
      case "Increase tickrate":
        this.increaseSpeed();
        break;
      case "Decrease tickrate":
        this.decreaseSpeed();
        break;
      case "Toggle loop":
        this.toggleLooping();
        break;
      case "check box":
        view.refresh(model.getShapes(), model.getTime());
      default:
        //do nothing
        break;
    }
  }

  @Override
  public void refresh() {
    System.out.println(this.model.getTime());
    System.out.println("Endtime: " + this.model.getEndTime());

    if (this.model.getTime() >= this.model.getEndTime() && looping) {
      this.restart();
      return;
    }

    this.model.tickTime();
    this.model.performAnimations();
    this.view.refresh(this.model.getShapes(), this.model.getTime());
  }

  @Override
  public void start() {
    timer.start();
  }

  @Override
  public void pause() {
    timer.stop();
  }

  @Override
  public void restart() {
    System.out.println(this.model.getShapes().size() + ", " + this.model.getAnimations().size() +
            ", " + startingShapes.size());
    this.model.setTime(1);
    this.model.setShapes(startingShapes);
  }

  @Override
  public void toggleLooping() {
    this.looping = !looping;
  }

  @Override
  public void increaseSpeed() {
    if (this.tickrate == 1) {
      this.start();
    }
    this.tickrate += 1;

    System.out.println(tickrate);
    this.timer.setDelay(1000 / tickrate);
  }

  @Override
  public void decreaseSpeed() {
    if (this.tickrate > 1) {
      this.tickrate -= 1;
    }
    if (this.tickrate == 1) {
      this.pause();
    }
    System.out.println(tickrate);
    this.timer.setDelay(1000 / tickrate);
  }
}
