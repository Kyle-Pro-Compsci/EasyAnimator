package cs3500.animator.animations;

/**
 * Represents the different types of animations.
 */

public enum AnimationName {
  MOVE,
  SCALE,
  CHANGECOLOR;
}
