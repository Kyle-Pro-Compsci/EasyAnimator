package cs3500.shapes;

/**
 * Represents the different types of Shapes.
 */

public enum ShapeType {
  RECTANGLE,
  OVAL;

}
